#!/bin/bash

result=""
prev="0" 
prevB=0
found=1
var=0
findUnique=$2
outputfile="$3"
#`echo "$1" | awk -F/ '{print $(NF)}'`

if [ -f output.temp ]
then
	  rm -f output.temp 
fi

while read i
	do 
        numA=$(echo "$i" | awk '{print $5}')
	numB=$(echo "$i" | awk '{print $2}')

	if [ "`echo "$numA" | head -c 1`" != "[" ]
	then
		numA=$(echo "$i" | awk '{print $6}')
	fi 
	
	#remove any trailing ,
	
	if [ `echo "${numB: -1}"` = "," ]
	then
		size=${#numB}
		#${#myvar}
		size=$(($size - 1))
		#numB= To be continued..................................
		numB=`echo "$numB" | cut -c 1-$size`
	fi
	
	#??  $prevB  ??  $numB ?? $found ??  $numB

	if [ "$prev" = "$numA" ] #&& [ "$prevB" != "$numB" ]
	then
		if [ "$findUnique" = "y" ]  || [ "$findUnique" = "Y" ]
		then
			if [ "$prevB" != "$numB" ] && [ `echo "$found" | grep "$numB" | wc -l` -eq 0 ] 
			then
				var=$((var+1)) 
			fi
		else
			var=$((var+1))
		fi
	fi

	if [ "$prev" != "$numA" ] && [ "$prev" != "0" ] 
	then 
		found=0
		prevB=0

		if [ $var -ne 0 ]
	 	then
			 var=$((var+1))	
			 result=`echo -e "$result \n $prev $var"`
		fi 
		var=0
		prev=0
	else 
		prev=$numA
		prevB=$numB
		found=" $found $numB "
	fi
done< "$1"
echo -e  "RESULT\n==============$result" > output.temp

#### summarize info###########
result=`echo $result | grep -v "^$"`
if [ `echo "$result" | wc -l` -gt 0 ]
then
	max=0
	min=10000000000
	total=0
	counter=1

	result=`echo $result | grep -v "^$"`
	while read x
			do
			## check if value is numeric
			curvar=`echo "$x" | awk '{print $2}'`
			if [ "$(echo $curvar | grep "^[ [:digit:] ]*$")" ]
			then
					total=$((total+curvar))
					counter=$((counter+1))
					[ $curvar -gt $max ] &&  { max=$curvar;}
					[ $curvar -lt $min ] && { min=$curvar; }

			fi
	done < "output.temp"
	#<< "$result"
	if [ $max -ne 0 ] 
	then
		echo -e " \nSUMMARY     $1\n==============\n min: $min\n max: $max\n total:$total\n average:$((total/counter))" |  tee -a $outputfile
	fi
fi
#echo -e "RESULT\n==============$result"

