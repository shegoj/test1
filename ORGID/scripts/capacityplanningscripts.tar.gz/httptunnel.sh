#!/bin/bash
counter=`netstat -anop | grep 1059 | grep LISTEN | grep  ssh | wc -l`
if [ $counter -gt 1 ]; then
	kill -9 `netstat -anop | grep 1059 | grep LISTEN | grep  ssh | head -1 |awk  '{print $7}' | awk -F/ '{print $1}'`
fi
#ssh -T -g -L 1059:$1.int.thomsonreuters.com:1055 m186742@167.68.246.57 &
ssh -N -f -L 1059:$1.int.thomsonreuters.com:1055 m186742@167.68.246.57 &
sleep 1
