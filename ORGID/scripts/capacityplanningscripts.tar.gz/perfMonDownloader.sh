#!/bin/bash
EXPECTED_ARGS=4
if [ $# -lt $EXPECTED_ARGS ] 
then
	 echo "Usage: `basename $0`1 10 2014 EUAT y (i.e day month year env y)"
	 exit 1
fi 
dir=downloads/$4/$1_$2_$3

rm -rf $dir
mkdir -p $dir

#echo -e "\nfiles will be downloaded to $dir\n"

sp='/-\|'
printf ' '

! [ -f conf/hosts ] && { echo "conf/hosts file not found. Script will now exit..."; exit 1;}
for i in `cat conf/hosts | grep $4`; do

	printf '\b%.1s' "$sp"
  	sp=${sp#?}${sp%???}

	hostServer=`echo "$i"  | awk -F? '{ print $1 }'`
	hostAlias=`echo "$i" | awk -F? '{ print $2 }'`
	#echo "Processing $hostServer alias $hostAlias"
#	ssh -T -fo -L 1057:$hostServer.int.thomsonreuters.com:1055 m186742@167.68.246.57 & 
#	nohup ssh -T -g -L 1059:$hostServer.int.thomsonreuters.com:1055 m186742@167.68.246.57 & 
#	./test2.sh &
#	kill -9 `netstat -anop | grep 1059 | head -1 |awk  '{print $7}' | awk -F/ '{print $1}'`
	./httptunnel.sh $hostServer &

	pidValue=`echo $!`
	[ -x $dir/$hostAlias ] && [ rm -f $dir/$hostAlias ]

        printf '\b%.1s' "$sp"
        sp=${sp#?}${sp%???}
	
	sleep 3
	if [ $1 = "-" ]
	then
		wget --no-proxy  -q  -O $dir/$hostAlias "http://localhost:1059/data?mo=$2&ye=$3" 2>&1
	else
		wget --no-proxy  -q  -O $dir/$hostAlias "http://localhost:1059/data?da=$1&mo=$2&ye=$3" 2>&1
	fi
	EXIT_NOW=0
	md5value="0"


	
        printf '\b%.1s' "$sp"
        sp=${sp#?}${sp%???}

	while [ $EXIT_NOW -eq 0  ]
	do
		curmd5value=`md5sum $dir/$hostAlias |awk '{print $1}'`
		if [ $md5value=$curmd5value ]; then
			EXIT_NOW=1
		fi
		md5value=`md5sum $dir/$hostAlias |awk '{print $1}'`		
		sleep 2
	done
done
echo -e  "\nDownload Complete Done"

if [ $# -gt 4 ] && [ $EXIT_NOW -eq 1 ]
then
	echo -e "\nNow performing analysis on the files\n\n"
	outputFile=`date '+%b_%d_%Y_%H.%M.%S'"_out"`

	for k in `ls $dir/*`
	do
		#echo "$outputFile"
		./process.sh "$k" >> $dir/$outputFile
	done

#	echo -e "\n result in $outputFile
fi

echo -e "\nfiles  downloaded to $dir\n"
