#./apacheLogdownloader.sh WEB oct/2014
period=`echo "$2" | awk -F/ '{print $1_$2}'`
dir="downloads/$1/$period"
rm -rf $dir
mkdir -p $dir

for i in `cat conf/hosts | grep -i $1 | grep -i "Web"`
#for i in `cat conf/hosts | grep -i $1 | grep -i "ORGID_WEB"`
do 
	hostServer=`echo "$i"  | awk -F? '{ print $1 }'`
	hostAlias=`echo "$i" | awk -F? '{ print $2 }'`
	echo $hostServer
	#ssh -q m186742@jump "ssh -q asadmin@$hostServer '\'' echo $date;for i in \`find /appserver/apache_egrc/logs -name 'access*'  -mtime -32 -exec ls -1rt '{}' +; \`;do  grep -i 'oct/2014' '$i' ;done'\''";
	ssh -q m186742@jump "ssh -q asadmin@$hostServer 'grep -i $2 /appserver/apache_egrc/logs/*access* '" > $dir/APACHE_$hostAlias.log
#/appserver/apache_egrc/logs -name access'";
done

## now process concurrency
echo -e "\n Generating Concurrency Report \n"
for k in `ls $dir`
do
	./concurrent.sh "$dir/$k" y "$dir/concurrent_result.txt"
	./bandwidthusage.sh "$dir/$k"  "$dir/bandwidth_result.txt"
done
