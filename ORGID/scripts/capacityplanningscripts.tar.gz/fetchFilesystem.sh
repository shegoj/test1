#!/bin/bash
#dir=donwloads/df/$3/$1_$2
#rm -rf $dir
#mkdir -p $dir
for i in `cat conf/hosts | grep -i $1`; do
	hostServer=`echo "$i"  | awk -F? '{ print $1 }'`
	hostAlias=`echo "$i" | awk -F? '{ print $2 }'`
	echo -e "\n\n$hostServer ($hostAlias) Filesystem , Disk Usage"
	#$(ssh -q m186742@jump 'ssh -q asadmin@$hostServer "df -h"') #| grep -E "log$|mr$|appserver$|var$|perf$|home$|grc_rtsl_data$ | grep -v "vol" | awk '{print $(NF) " : " $(NF-1)}'
	ssh -q m186742@jump "ssh -q asadmin@$hostServer 'df -h'" | grep -E "log$|mr$|appserver$|var$|perf$|home$|grc_rtsl_data$" | grep -v "vol" | awk '{print $(NF) " , " $(NF-1)}'
#	echo "$(asadmin@$hostServer')"
done
