logfile="$1"
valuex=0
counter=0

outputfile="$2"

while read x
	do
	valueI=`echo "$x" |  awk '{ print ( $(NF)) }'`
	if [ "$(echo $valueI | grep "^[ [:digit:] ]*$")" ]
	then
		counter=$((counter + 1))
		valuex=$((valuex + $valueI))
	fi
done< "$1"

if [ $counter -gt 0 ]
then
	echo -e " Summary \n==========\n Total number of requests: $counter\n total bandwidth used: $valuex\n average bandwidth per request:$((valuex/counter))" |  tee -a $outputfile
fi
