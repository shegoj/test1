#!/bin/bash
#Script written by Olusegun Ojewale for Thomson Reuters"
#14/01/2015


## script downloads broswer information captured by Apache for specific date  range (e.g. 'Dec 2014') from specific server(s).
#  it then evaluate ratio/percentage of broswers hitting the Apache server'
#  Currently emphasis is on Chrome, Firefox and IE 7,8,9,10,11'

MIN_EXP_ARG=3
REMOTE_FILE_PREFIX=bro

totalcount=0
IE7_count=0
IE8_count=0
IE9_count=0
IE10_count=0
IE11_count=0
Chrome_count=0
Firefox_count=0

if [ $# -lt $MIN_EXP_ARG ]
then
         echo "Usage: `basename $0` Dec 2014 EUAT  (i.e month year env)"
         exit 1
fi

dir=downloads/$3/BW/$1_$2

rm -rf $dir
mkdir -p $dir



for i in `cat conf/hosts | grep -i $3 | grep "ORGID_WEB"`; do
        hostServer=`echo "$i"  | awk -F? '{ print $1 }'`
        hostAlias=`echo "$i" | awk -F? '{ print $2 }'`
	echo -e "\n\n$hostServer ($hostAlias) extracting data from server"
	ssh -q m186742@jump "ssh -q asadmin@$hostServer 'cd /appserver/apache_egrc/logs;grep -i $1\/$2 bro* | grep -i mozilla'" >> $dir/cleanedup.log
done

logdata="$dir/cleanedup.log"

#check if data was downlaoded and there are records to processs

if [ -s "$logdata" ]
then
	totalcount=`wc -l $logdata |awk '{print $1}'`
	IE7_count=`grep 'MSIE 7' $logdata | wc -l`
	IE8_count=`grep 'MSIE 8' $logdata | wc -l`
	IE9_count=`grep 'MSIE 9' $logdata | wc -l`
	IE10_count=`grep 'MSIE 10' $logdata | wc -l`
	IE11_count=`grep 'rv:11' $logdata | wc -l`

	
	Chrome_count=`grep 'Chrome/' $logdata | wc -l`
	Firefox_count=`grep 'Firefox' $logdata | wc -l`
	
	echo $IE7_count $I8_count $IE9_count $IE10_count $IE11_count $Chrome_count $Firefox_count $totalcount
        Firefox_percent=$(printf '%i %i' $Firefox_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')
        Chrome_percent=$(printf '%i %i' $Chrome_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')
        IE7_percent=$(printf '%i %i' $IE7_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')
        IE8_percent=$(printf '%i %i' $IE8_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')
        IE9_percent=$(printf '%i %i' $IE9_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')
        IE10_percent=$(printf '%i %i' $IE10_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')
        IE11_percent=$(printf '%i %i' $IE11_count $totalcount | awk '{ pc=100*$1/$2;  printf "%.2f\n", pc  }')

	others_percent=$(printf '%f %f %f %f %f %f %f' $IE7_percent $IE8_percent $IE9_percent $IE10_percent $IE11_percent $Firefox_percent $Chrome_percent | awk '{ others=100 -($1+$2+$3+$4+$5+$6+$7);  printf "%.2f\n", others }')
	echo $IE11_percent, $others_percent

	echo "\nIE7		$IE7_percent";
	echo "\nIE8		$IE8_percent";
	echo "\nIE9		$IE9_percent";
	echo "\nIE10		$IE10_percent";
	echo "\nIE11		$IE11_percent";
	echo "\nChrome		$Chrome_percent";
	echo "\nFirefox		$Firefox_percent";

	echo "\nOthers          $others_percent";

fi 
	  


 
