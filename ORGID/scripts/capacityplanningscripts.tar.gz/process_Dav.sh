logfile="$1"
valueW=0
totalW=0
counterW=0
maxW=-10

valueC=0
totalC=0
counterC=0
maxC=-10

valueL=0
totalL=0
counterL=0
maxL=-10

valuePi=0
totalPi=0
counterPi=0
maxPi=-10


valuePo=0
totalPo=0
counterPo=0
maxPo=-10

valueTinUse=0
totalTinUse=0
maxTinUse=-10

valueMinFree=0
totalMinFree=0
counterMinFree=0
maxMinFree=10000000000


valueTo=0
totalTo=0
counterTo=0
maxTo=-10

fileName="$1.processing"
tail -n +2 "$1" > "$fileName"

ramtotal=`head -1 "$fileName" | awk -F, '{print $48}'`


#printf '\b%.1s' "$sp"
#sp=${sp#?}${sp%???}


while read x
        do
	
	#echo "hey" 
	#printf '\b%.1s' "$sp"
	#sp=${sp#?}${sp%???}

	valueC=`echo "$x" |  awk -F, '{ print $8}'` # get CPU field
	
        counterC=$((counterC + 1))
        [ $maxC -lt $valueC ] && { maxC=$valueC; timeC=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
        totalC=$((totalC + valueC))
        

        valueL=`echo "$x" |  awk -F, '{ print $17}'`

        
         #counterL=$((counterL + 1))
         [ $maxL -lt $valueL ] && { maxL=$valueL; timeL=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalL=$((totalL + valueL))
        

        valueW=`echo "$x" |  awk -F, '{ print $11}'`

        
         #counterW=$((counterW + 1))
         [ $maxW -lt $valueW ] && { maxW=$valueW; timeW=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalW=$((totalW + valueW))

        valuePi=`echo "$x" |  awk -F, '{ print $63}'`
        
         #counterPi=$((counterPi + 1))
         [ $maxPi -lt $valuePi ] && { maxPi=$valuePi; timePi=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalPi=$((totalPi + valuePi))

        valuePo=`echo "$x" |  awk -F, '{ print $64}'`

         #counterPo=$((counterPo + 1))
         [ $maxPo -lt $valuePo ] && { maxPo=$valuePo; timePo=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalPo=$((totalPo + valuePo))

        valueTinUse=`echo "$x" |  awk -F, '{ print $69}'`

        
         #counterTinUse=$((counterTinUse + 1))
         [ $maxTinUse -lt $valueTinUse ] && { maxTinUse=$valueTinUse; timeTinUse=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalTinUse=$((totalTinUse + valueTinUse))

         valueTo=`echo "$x" |  awk -F, '{ print $70}'`
        
         #counterTo=$((counterTo + 1))
         [ $maxTo -lt $valueTo ] && { maxTo=$valueTo; timeTo=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalTo=$((totalTo + valueTo))
		 
	 valueMinFree=`echo "$x" |  awk -F, '{ print $49}'`
         #counterTinUse=$((counterTinUse + 1))
         [ $valueMinFree -lt $maxMinFree ] && { maxMinFree=$valueMinFree; timeMinFree=`echo "$x" |  awk -F, '{print $1 " " $2}'`;}
         totalMinFree=$((totalMinFree + valueMinFree))
		 
		 
done< "$fileName" 

[ -f  "$fileName" ] && { rm -rf  "$fileName";}

if [ $counterC -gt 0 ]
then
	echo -e " Summary  $1\n==========\n" 
	resultC=`echo "scale=2;$totalC/$counterC" | bc -l`
	resultL=`echo "scale=2;$totalL/$counterC" | bc -l`
	resultW=`echo "scale=2;$totalW/$counterC" | bc -l`
	resultPi=`echo "scale=2;$totalPi/$counterC" | bc -l`
	resultPo=`echo "scale=2;$totalPo/$counterC" | bc -l`
    	resultTinUse=`echo "scale=2;$totalTinUse/$counterC" | bc -l`
    	resultTo=`echo "scale=2;$totalTo/$counterC" | bc -l`
    	resultAvgMmInUse=`echo "scale=2;(($ramtotal-$totalMinFree/$counterC)*100/$ramtotal)" | bc -l`
	MaxMmInUse=`echo "scale=2;(($ramtotal-$maxMinFree)*100)/$ramtotal" | bc -l`
	

	echo -e "CPU Load Average  in Running Queue Per Minute		: $resultL \nMax Load In  Running Queue         			: $maxL @ $timeL\n"
 	echo -e  "Average % CPU Utilization                   		: $resultC% \nMax Utilization at a given Time   			: $maxC% @ $timeC\n"
 	echo -e  "Average % CPU time spent on IOWAIT         	 	: $resultW% \nMax  % CPU time spent on IOWAIT   			: $maxW% @ $timeW\n"
 	echo -e  "Average Number of Inbound Bytes           		: $resultPi \nMax Number of Inbound Bytes     			        : $maxPi @ $timePi\n"
    	echo -e  "Average Number of Outbound Bytes         	 	: $resultPo \nMax Number of Outbound Bytes       			: $maxPo @ $timePo\n" 
    	echo -e  "Average Number of TCP Sockets in Use    		: $resultTinUse \nMax No of TCP Sockets in Use  				: $maxTinUse @ $timeTinUse\n"
    	echo -e  "Average % of Memory In use                       	: $resultAvgMmInUse%\nMax % of Memory In use 		   			: $MaxMmInUse% @ $timeMinFree\n"

       # echo -e " Summary \n==========\n Total number of requests: $counterC\n total bandwidth used: $totalC\n average bandwidth per request: $resultC"
fi
